//
//  Capital.swift
//  pinAnnotationViewTest
//
//  Created by Local Account 123-17 on 11/17/16.
//  Copyright © 2016 Local Account 123-17. All rights reserved.
//

import MapKit
import UIKit

class Capital: NSObject, MKAnnotation {
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var info: String
    
    init(title: String, coordinate: CLLocationCoordinate2D, info: String) {
        self.title = title
        self.coordinate = coordinate
        self.info = info
    }
}
